package com.connectme.model;

public class chatting {

}
